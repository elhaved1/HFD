@echo off
echo Open this folder in Android Studio, wait for Gradle Sync, then choose:
echo Build ^> Build Bundle(s) / APK(s) ^> Build APK(s)
pause
